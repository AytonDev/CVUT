//
// Created by Lukáš Frajt on 13/05/2018.
//

#include "baseGame.h"

CBaseGame::CBaseGame(const CQuizManager &quiz): m_Quiz(quiz), m_Points(0) {

}

CBaseGame::~CBaseGame() {

}