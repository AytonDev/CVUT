//
// Created by Lukáš Frajt on 13/05/2018.
//

#include "fileManager.h"

CFileManager::CFileManager(string quizes): m_QuizesFileName(quizes) {

}
